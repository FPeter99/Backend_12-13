<?php

namespace BevBox\Products;

use Exception;

class Drink {

    private int $id;
    private string $name;
    private int $price;
    private int $stock;
    private float $volume; // 0.33


    private static array $drinks = [
        1 => "Cola",
        2 => "Cola Zero",
        3 => "Orange",
        4 => "OrangeZero",
        5 => "Espresso",
        6 => "IceTea - Peach",
        7 => "IceTea - Lemon",
        8 => "IceTea - Lemon Zero",
    ];

    /**
     * @param int $id
     * @param string $name
     * @param int $price
     * @param int $stock
     * @param float $volume
     */
    public function __construct(int $id, string $name, int $price, int $stock, float $volume)
    {
        $this->id = $id;
        $this->name = $name;
        $this->price = $price;
        $this->stock = $stock;
        $this->volume = $volume;
    }

    public function __get(string $name):mixed{
        if($name == "img")
        {
            return "./img/" + $this->id + ".png";
        }
        if(property_exists($this,$name))
        {
            return $this->$name;
        }
        throw new Exception("Unknown property: $name");
    }


}