<?php 





?>





<div class="mx-auto max-w-7xl px-4 flex-grow">

<h1 class="my-4 text-center text-4xl font-bold text-cyan-600">
    <?= $drink->name?> </h1>

<div class="max-w-sm w-full bg-white rounded-md shadow-md overflow-hidden">

    <img src="./img/<?= $drink->id?>.png" alt="<?= $drink->name?>" class="w-full h-64 object-cover" />

    <div class="p-6 space-y-4">

        <p class="text-3xl font-bold text-cyan-700 text-right">
            <?= $drink->price ?>
        </p>


        <div class="flex items-center justify-between">
            <span class="text-cyan-700">
                Volume
            </span>

            <span class="font-semibold text-cyan-700">
            <?= $drink->volume ?> L
            </span>
        </div>

        <div class="flex items-center justify-between">
            <span class="text-cyan-700">
                Stock
            </span>

            <span class="font-semibold text-green-600">
                <?= $drink->stock ?> db
            </span>
        </div>