<?php declare(strict_types=1); ?>

<h1 class="my-4 text-center text-4xl font-bold text-cyan-600">
    <?= $title ?>
</h1>


<div class="mx-auto max-w-7xl px-4 py-4 flex-grow new">

    <form action="index.php?action=new" method="POST" class="grid gap-1">

        <label for="name">Név</label>
        <input type="text" name="name" id="name"
            class="p-2 border border-cyan-700  focus:outline-none focus:ring-2 focus:ring-cyan-400 rounded-md">



        <label for="price">Ár</label>
        <input type="number" name="price" id="price"
            class="p-2 border border-cyan-700  focus:outline-none focus:ring-2 focus:ring-cyan-400 rounded-md">



        <label for="stock">Készlet</label>
        <input type="number" name="stock" id="stock"
            class="p-2 border border-cyan-700  focus:outline-none focus:ring-2 focus:ring-cyan-400 rounded-md">



        <label for="volume">Kiszerelés</label>
        <input type="number" name="volume" id="volume" step="0.01"
            class="p-2 border border-cyan-700  focus:outline-none focus:ring-2 focus:ring-cyan-400 rounded-md"
            >


            
        <button class="bg-cyan-700 text-white p-2 hover:bg-cyan-800 rounded-md">
            Mentés
        </button>

    </form>
</div>