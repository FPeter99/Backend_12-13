<!DOCTYPE html>
<html lang="hu">


<body class="min-h-screen flex flex-col">


    <div class="mx-auto max-w-7xl px-4 flex-grow">

        <h1 class="my-4 text-center text-4xl font-bold text-cyan-600">
            Italok </h1>


        <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        <?php 
        foreach($list as $drink): ?>


            <div class="group rounded-xl border border-gray-200 bg-white p-4">

                <h2 class="mb-3 text-l font-semibold text-cyan-600">
                    <a href="index.php?action=show&id=<?= $drink->id ?>" class="text-cyan-600 font-semibold">
                        <?= $drink -> name ?> </a>
                </h2>

                <p class="text-gray-500">Űrtartalom: <?= $drink -> volume ?> </p>

                <div class="flex justify-between items-center">
                    <span class="<?= $drink -> stock > 0? "bg-green-800" : "bg-red-800" ?> text-white rounded-sm p-1"><?= $drink -> stock > 0 ? "Elérető" : "Elfogyott"?></span>

                    <span class="pt-2 text-lg font-bold text-cyan-700 text-right"><?= $drink -> price?>&nbsp;Ft
                    </span>
                </div>

            </div>
        <?php endforeach ?>

        </div>


    </div>



    </div>
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
        crossorigin="anonymous"></script>
</body>

</html>