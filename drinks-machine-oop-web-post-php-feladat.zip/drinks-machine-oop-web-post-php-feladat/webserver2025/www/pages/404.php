<div class="mx-auto max-w-7xl px-4 flex-grow">

    <h1 class="my-4 text-center text-4xl font-bold text-cyan-600">
        <?= $title ?>
    </h1>

    <img src="img/404.png" alt="">
    <p></p>
</div>