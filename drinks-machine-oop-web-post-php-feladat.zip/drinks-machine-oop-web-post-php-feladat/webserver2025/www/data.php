<?php

use BevBox\Products\Drink;


$list = [];

$f = fopen($path, "r");
fgets($f);

while (($data = fgetcsv($f, 1000, ";",'"', "\\")) !== FALSE) {
    array_push($list, new Drink(intval($data[0]), $data[1], intval($data[2]), intval($data[3]), floatval($data[4])));
}
fclose($f);



?>