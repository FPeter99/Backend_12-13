<?php
require __DIR__ . '/vendor/autoload.php';

$whoops = new \Whoops\Run;
$whoops->pushHandler(new \Whoops\Handler\PrettyPageHandler);
$whoops->register();

$path = __DIR__ . "/drinks.csv";


include("data.php");



$qp_action = "products";


if(!empty($_GET["action"]))
{
    $qp_action = $_GET["action"];
    if(!in_array($qp_action, ["show", "new", "products"]))
    {
        $qp_action = 404;
    }
}

$menuItems = 
[
    [
        "text" => "Főoldal",
        "url" => "index.php",
        "active" => $qp_action == "products",
    ],
    [
        "text" => "Új ital",
        "url" => "index.php?action=new",
        "active" => $qp_action == "new"
    ],

];

if($qp_action == "products")
{
    $title = "Italok";

}
else if($qp_action == "show")
{
    
    $id = $_GET["id"];
    $drink=array_find($list, fn($drink) => $drink->id == $id);
    if(!is_null($drink)){$title=$drink->name;}
    else{$qp_action = 404;}
}
else if($qp_action == "new")
{
    $title = "Új ital";
}



if($qp_action == 404)
{
    $title = "error: 1367";
}


function cmp($a, $b)
{
    return $a->name <=> $b->name;
}

usort($list, "cmp");

if(404 == $qp_action)
{
    header("HTTP/1.1 404 Not Found");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>

</head>
<body class="min-h-screen flex flex-col">
    <?php
    include("./components/menu.php");
    
    if($qp_action == "products")
    {
        include("./pages/products.php");
    }
    else if($qp_action == "show")
    {
        include("./pages/drink.php");
    }
    else if($qp_action == "new")
    {
        include("./pages/new.php");
    }
    else
    {
        include("./pages/404.php");
    }
    
    ?>
</body>
</html>
