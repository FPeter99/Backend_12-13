<?php

use App\Http\Controllers\CalcController;
use App\Http\Controllers\CalendarController;
use App\Http\Controllers\QuoteController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/idezetek/house', [QuoteController::class, 'house'])->name('quote.house');
Route::get('/idezetek/modern-family', [QuoteController::class, 'modernFamily'])->name('quote.modernFamily');
Route::get('/idezetek/uvegtigris/csoki', [QuoteController::class, 'uvegtigrisCsoki'])->name('quote.uvegtigrisCsoki');
Route::get('/idezetek/uvegtigris/lali', [QuoteController::class, 'uvegtigrisLali'])->name('quote.uvegtigrisLali');
Route::get('/idezetek/harry-potter/{slug}', [QuoteController::class, 'harryPotter'])->name('quote.harryPotter');

Route::get('/naptar/ma', [CalendarController::class, 'today'])->name('calendar.today');
Route::get('/naptar/tegnap', [CalendarController::class, 'yesterday'])->name('calendar.yesterday');
Route::get('/naptar/holnap', [CalendarController::class, 'tomorrow'])->name('calendar.tomorrow');

Route::get('/szamologep/{a}+{b}', [CalcController::class, 'add'])->whereNumber(['a', 'b'])->name('calc.add');
Route::get('/szamologep/{a}-{b}', [CalcController::class, 'subtract'])->whereNumber(['a', 'b'])->name('calc.subtract');
Route::get('/szamologep/{a}*{b}', [CalcController::class, 'multiply'])->whereNumber(['a', 'b'])->name('calc.multiply');
Route::get('/szamologep/{a}/{b}', [CalcController::class, 'divide'])->whereNumber(['a', 'b'])->name('calc.divide');
