<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DateTime;
use DateInterval;

class CalendarController extends Controller
{
    public function today()
    {
        $date = new DateTime();
        return [
            "data" => [
                "title" => "Ma",
                "date" => $this->format($date),
            ]
        ];
    }

    public function yesterday()
    {
        $date = new DateTime();
        $date->sub(new DateInterval("P1D"));
        return [
            "data" => [
                "title" => "Tegnap",
                "date" => $this->format($date),
            ]
        ];
    }

    public function tomorrow()
    {
        $date = new DateTime();
        $date->add(new DateInterval("P1D"));
        return [
            "data" => [
                "title" => "Holnap",
                "date" => $this->format($date),
            ]
        ];
    }

    private function format(DateTime $date): string
    {
        return $date->format("Y-m-d");
    }
}
