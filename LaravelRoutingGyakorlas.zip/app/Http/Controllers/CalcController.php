<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CalcController extends Controller
{
    public function add(string $a, string $b)
    {
        $numA = (int) $a;
        $numB = (int) $b;
        return [
            "data" => [
                "title" => "Összeadás",
                "a" => $numA,
                "b" => $numB,
                "result" => $numA + $numB,
            ]
        ];
    }

    public function subtract(string $a, string $b)
    {
        $numA = (int) $a;
        $numB = (int) $b;
        return [
            "data" => [
                "title" => "Kivonás",
                "a" => $numA,
                "b" => $numB,
                "result" => $numA - $numB,
            ]
        ];
    }

    public function multiply(string $a, string $b)
    {
        $numA = (int) $a;
        $numB = (int) $b;
        return [
            "data" => [
                "title" => "Szorzás",
                "a" => $numA,
                "b" => $numB,
                "result" => $numA * $numB,
            ]
        ];
    }

    public function divide(string $a, string $b)
    {
        $numA = (int) $a;
        $numB = (int) $b;

        if ($numB === 0) {
            abort(400, "Nullával való osztás nem értelmezett!");
        }

        return [
            "data" => [
                "title" => "Osztás",
                "a" => $numA,
                "b" => $numB,
                "result" => $numA / $numB,
            ]
        ];
    }

    // Magyar elnevezésű alias metódusok
    public function osszeadas(string $a, string $b)
    {
        return $this->add($a, $b);
    }

    public function kivonas(string $a, string $b)
    {
        return $this->subtract($a, $b);
    }

    public function szorzas(string $a, string $b)
    {
        return $this->multiply($a, $b);
    }

    public function osztas(string $a, string $b)
    {
        return $this->divide($a, $b);
    }
}
